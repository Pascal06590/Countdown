$(document).ready(function() {
  /* variables */
  var clockFace = document.getElementById("clock_face"),
    clockBack = document.getElementById("clock_back"),
    showClockTime = document.getElementById("clock_time"),
    clockdecompteur = document.getElementById("clock_decompteur"),
    clockStart = document.getElementById("clock_start"),
    showdecompteurLength = document.getElementById("decompteur_length"),
    countingDown = false,
    decompteurMinus = document.getElementById("decompteur_minus"),
    decompteurPlus = document.getElementById("decompteur_plus"),
    decompteurTime = Number(showdecompteurLength.innerHTML),
    counter,
    sec = minsToSecs(decompteurTime),
    totalTime = sec,
    fillSize = 240,
    resetButton = document.getElementById("reset");

  /* functions */
  function minsToSecs(m){
    // minutes en secondes
    var inSeconds =  m * 60;
    return inSeconds;
  }

  function secsToTime(s){
    // seconds en MM:SS
    var mins = Math.floor(s / 60);
    var secsRemaining = s % 60;
    if (secsRemaining < 10) {
      return mins + ":0" + secsRemaining;
    } else {
      return mins + ":" + secsRemaining;
    }
  }

  function displayTime(s) {
    clockStart.style.visibility="hidden";
    showClockTime.innerHTML = secsToTime(s);
      clockdecompteur.innerHTML = "Décompteur ON";
      clockFace.style.backgroundColor="rgba(102, 186, 18, 0.7)";
      clockFace.style.borderColor="#66BA12";
  }

  function initialiseClock() {
    showClockTime.innerHTML = decompteurTime;
  }

  function resetClock(bool) {
    clockStart.style.visibility="visible";
    clockStart.innerHTML="Click pour Démarrer";
    clockStart.style.color="#fff";
    if (bool) {
        showClockTime.innerHTML = decompteurTime;
        clockBack.style.marginTop="240px";
    }
    else if (!bool){
      clearInterval(counter);
      countingDown = false;
      sec = minsToSecs(decompteurTime);
      totalTime = sec;
      showClockTime.innerHTML = decompteurTime;
      clockBack.style.marginTop="240px";
      clockdecompteur.innerHTML = "Décompteur OFF";
      clockFace.style.backgroundColor="rgba(196, 37, 37, 0.7)";
      clockFace.style.borderColor="#66BA12";
    }
  }

  function controlTimer() {
    if (countingDown) {
      //stop décompteur
      countingDown = false;
      stopTimer();
      return;
    }
    else {
      //start décompteur
      startTimer();
    }
  }

  function startTimer() {
    counter = setInterval(countDown, 1000);
    countingDown = true;
  }

  function stopTimer() {
    clearInterval(counter);
    countingDown = false;
    if (sec > 0) {
      clockStart.innerHTML="En Pause";
    }
    clockStart.style.visibility="visible";
    clockStart.style.color="rgba(196, 37, 37, 0.7)";
  }

  function countDown() {
    sec--;
    displayTime(sec);
    clockFill(sec,totalTime);
    if (sec === 0) {
		resetClock(false);
    }
  }

  /* ajuste le temps */
  function adjustTime(brk, inc){
    if (countingDown){
      return;
      } else /*augmente*/ {
        if(inc) {
          decompteurTime++;
          showdecompteurLength.innerHTML = decompteurTime;
        } else /*diminue*/ {
          if (decompteurTime > 1) {
            decompteurTime--;
            showdecompteurLength.innerHTML = decompteurTime;
            if (!onBreak) {
              sec = minsToSecs(decompteurTime);
              totalTime = minsToSecs(decompteurTime);
              resetClock(true);
          }
        }
      }
    }
  }
  /* suivis du temps */
  function clockFill(s,t){
    if(s === 0) {
      fillSize = 0;
    } else {
      fillSize = Math.ceil((s+1)/t*240);
    }
    clockBack.style.marginTop=fillSize + "px";
  }

  initialiseClock();

  clockFace.addEventListener("click", controlTimer);
  decompteurPlus.addEventListener("click",function() {
    adjustTime(false,true);
  });
  decompteurMinus.addEventListener("click",function() {
    adjustTime(false,false);
  });
  resetButton.addEventListener("click",function() {
    resetClock(false);
  });

});
